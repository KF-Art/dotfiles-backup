## SETUP
localdir=                                                                   # Where both cereus-core and extra will be stored locally
hostdir=                                                                    # The path to hostdir/binpkgs inside cereus-package cloned repo
pemdir=                                                                     # The path to PEM private key
pempass="LocOsbestdistro4509"                                               # The passphrase for PEM private key
user=                                                                       # The account you use for login at SourceForge
for scripts in fetchrepos signpkgs signrepos syncpkgs upkgs; do
    sed -i 's|localdir=dummy|localdir='"${localdir}"'|g' ${scripts}
    sed -i 's|pemdir=dummy|pemdir='"${pemdir}"'|g' ${scripts}
    sed -i 's|pempass=dummy|pempass='"${pempass}"'|g' ${scripts}
    sed -i 's|user=dummy|user='"${user}"'|g' ${scripts}
    sed -i 's|hostdir=dummy|hostdir='"${hostdir}"'|g' ${scripts}
done

chmod u+x ./*
